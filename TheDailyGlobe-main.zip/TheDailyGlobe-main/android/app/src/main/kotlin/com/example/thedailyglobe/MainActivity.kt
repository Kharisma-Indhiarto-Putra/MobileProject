package com.example.thedailyglobe

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
